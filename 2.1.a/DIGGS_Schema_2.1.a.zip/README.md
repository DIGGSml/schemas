# The Official DIGGSML Schema Repository

![alt text](https://www.geoinstitute.org/sites/default/files/inline-images/DIGGS%20use%20case.png "DIGGSml Use Case Diagram")
